months = [ "Jan", "Feb", "Mar", "Apr", "May", "Jun", "Jul", "Aug", "Sep", "Oct", "Nov", "Dec"]
Calendar = [ ["Jan",31] , ["Feb",28] , ["Mar",31], ["Apr",30], ["May",31], ["Jun",30], ["Jul",31], ["Aug",31], ["Sep",30], ["Oct",31], ["Nov",30], ["Dec",31]]


def getDayNum (date):
    daynumfordate = date.split()
    return (int(daynumfordate[1]))


    

def getMonthname (date):
    monthnamefordate = date.split()
    return (monthnamefordate[0])


   
def daysLeftinCurrentmonth (date):
    month = (getMonthname(date))
    daynow = (getDayNum(date))
    daysinmonth = Calendar[months.index(month)][1]
    return(daysinmonth - daynow)

def monthsInBetween (date1,date2):
    startMonth = getMonthname(date1)
    endMonth = getMonthname(date2)
    smonth = months.index(startMonth)
    emonth = months.index(endMonth)
    return ((emonth-smonth)-1)



def calendarcalculate (date1,date2):
    days = (daysLeftinCurrentmonth(date1)) + (getDayNum(date2))
    n = 1
    for i in range (0, monthsInBetween(date1,date2)):
        
        daysinmonth = Calendar[months.index(getMonthname(date1))+n][1]
        days = days + daysinmonth
        n = n +1
    return days



    
    
    
