from Assignment_5_muneeb_islam import *

date1 = input("Please input the first date with a space after the date number and a three letter month name")
date2 = input("Please input the second date with a space after the date number and a three letter month name")


print (calendarcalculate(date1,date2))
